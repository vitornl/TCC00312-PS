# One to many project
<p>Projeto exemplo de uma aplicação gerenciandos dados contendo um CRUD e paginação através de um GUI. Contempla comunicação com o banco de dados para persistencia das informações. Desenvolvido para desktop utilizando as seguintes tecnologias:</p> 

<ul>
  <li>JPA</li>
  <li>Hibernate</li>
  <li>Log4j</li>
</ul>


