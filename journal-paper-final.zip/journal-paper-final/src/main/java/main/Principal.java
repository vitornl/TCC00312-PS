package main;

import views.Invisivel;

public class Principal {
	public static void main(String[] args) {
		Invisivel frameInvisivel = new Invisivel();
		frameInvisivel.setVisible(false);
	}
}
