package lixo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import errors.PaperNaoEncontradoException;
import errors.ObjetoNaoEncontradoException;
import errors.JournalComPapersException;
import errors.JournalNaoEncontradoException;
import models.Paper;
import models.Journal;
import service.PaperService;
import service.JournalService;
import javax.swing.SwingConstants;

public class ExcluirJournal extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static PaperService  paperAppService;
	 private static JournalService  journalAppService;
		@SuppressWarnings("unused")
		private Journal umJournal;
		
		 static
		    {
		    	@SuppressWarnings("resource")
				ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");

		    	journalAppService = (JournalService)fabrica.getBean ("JournalService");
		    }
		 static
		    {
		    	@SuppressWarnings("resource")
				ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");

		    	paperAppService = (PaperService)fabrica.getBean ("PaperService");
		    }

	
	@SuppressWarnings("unchecked")
	public ExcluirJournal() {
		List<Journal> jounals = journalAppService.recuperaListaDeJournalsEPapers();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel lblExcolhaOJournal = new JLabel("Escolha o journal a ser exclu�do:");
		lblExcolhaOJournal.setHorizontalAlignment(SwingConstants.CENTER);
		lblExcolhaOJournal.setFont(new Font("Arial", Font.PLAIN, 16));
		lblExcolhaOJournal.setBounds(0, 69, 434, 36);
		contentPane.add(lblExcolhaOJournal);
		
		@SuppressWarnings("rawtypes")
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean valido = true;
				try {
					journalAppService.exclui(journalAppService.recuperaUmJournal(jounals.get(comboBox.getSelectedIndex()).getId()));
					int i = (int) paperAppService.recuperaQuantPeloIdDoJournal(jounals.get(comboBox.getSelectedIndex()).getId());
					List<Paper> papers = paperAppService.recuperaPapersPeloIdDoJournal(jounals.get(comboBox.getSelectedIndex()).getId());
					i=i-1;
					while(i>-1){
						paperAppService.exclui(papers.get(i));
						papers.remove(i);
						i=i-1;
					}
				} catch (JournalNaoEncontradoException | ObjetoNaoEncontradoException | PaperNaoEncontradoException | JournalComPapersException e) {
					valido = false;
					JOptionPane.showMessageDialog(null, "Exclus�o inv�lida, este journal possui papers associados !");
				}
				if(valido){
					JOptionPane.showMessageDialog(null, "Journal excluido com sucesso !");
					dispose();
				}
				valido = true;
			}
		});
		comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
		comboBox.setBounds(46, 116, 356, 19);
		comboBox.setModel(new DefaultComboBoxModel<Object>(jounals.toArray()));
		contentPane.add(comboBox);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Arial", Font.PLAIN, 12));
		btnCancelar.setBounds(165, 182, 109, 31);
		contentPane.add(btnCancelar);
		
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
		
	}
}
