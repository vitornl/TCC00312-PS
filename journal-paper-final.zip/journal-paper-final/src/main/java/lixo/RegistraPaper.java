package lixo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import errors.JournalNaoEncontradoException;
import errors.ViolacaoDeConstraintDesconhecidaException;
import models.Paper;
import models.Journal;
import service.PaperService;
import service.JournalService;

public class RegistraPaper extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private String resp;
	private JTextField campoValor;
	private Paper umPaper;
	private static PaperService  paperAppService;
	private static JournalService  journalAppService;
	
	@SuppressWarnings("unused")
	private Journal journal;
		
	 static{
		 @SuppressWarnings("resource")
		 ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");
		 journalAppService = (JournalService)fabrica.getBean ("JournalService");
	 }
	 static {
	    	@SuppressWarnings("resource")
			ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");

	    	paperAppService = (PaperService)fabrica.getBean ("PaperService");
	    }
	
		
	@SuppressWarnings("unchecked")
	public RegistraPaper() {
		List<Journal> journals = journalAppService.recuperaListaDeJournalsEPapers();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 628, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JTextField campoNome;
		contentPane.setLayout(null);
		campoNome = new JTextField();
		campoNome.setBounds(167, 42, 356, 26);
		getContentPane().add(campoNome);
		campoNome.setColumns(10);
		
		JLabel nomePaper = new JLabel("Nome do Paper:");
		nomePaper.setFont(new Font("Arial", Font.PLAIN, 14));
		nomePaper.setBounds(51, 41, 98, 26);
		getContentPane().add(nomePaper);
		
		@SuppressWarnings("rawtypes")
		JComboBox ListaJournals = new JComboBox();
		ListaJournals.setFont(new Font("Tahoma", Font.PLAIN, 14));
		ListaJournals.setBounds(167, 215, 363, 20);
		ListaJournals.setModel(new DefaultComboBoxModel<Object>(journals.toArray()));
		contentPane.add(ListaJournals);
		
		JLabel valorPaper = new JLabel("Valor:");
		valorPaper.setFont(new Font("Arial", Font.PLAIN, 14));
		valorPaper.setBounds(103, 133, 46, 21);
		getContentPane().add(valorPaper);
		
		campoValor = new JTextField();
		campoValor.setBounds(167, 131, 36, 26);
		contentPane.add(campoValor);
		campoValor.setColumns(10);
		
		JButton cadastrar = new JButton("Cadastrar");
		cadastrar.setFont(new Font("Arial", Font.PLAIN, 14));
		cadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean valido = true;
				try {
						umPaper = new Paper();
						umPaper.setNome(campoNome.getText().toUpperCase().trim());
						umPaper.setValor(Integer.parseInt(campoValor.getText()));
				    	Journal aux;
						aux = journalAppService.recuperaUmJournal(journals.get(ListaJournals.getSelectedIndex()).getId());
						umPaper.setJournal(aux);
					    paperAppService.inclui(umPaper);
					    
				} 
				catch (JournalNaoEncontradoException | NumberFormatException | ViolacaoDeConstraintDesconhecidaException e1) {
					valido = false;
					JOptionPane.showMessageDialog(null, "Informa��es invalidas, reveja os campos !");
				}
				if(valido){
					JOptionPane.showMessageDialog(null, "Paper cadastrado Com sucesso !");
				    dispose();
				}
				
				        
			}
		});
		cadastrar.setBounds(131, 276, 126, 41);
		contentPane.add(cadastrar);
		
		JButton voltar = new JButton("Voltar");
		voltar.setFont(new Font("Arial", Font.PLAIN, 14));
		voltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		voltar.setBounds(397, 276, 111, 41);
		contentPane.add(voltar);
		
		JLabel journal = new JLabel("Journals:");
		journal.setFont(new Font("Arial", Font.PLAIN, 14));
		journal.setBounds(60, 216, 89, 21);
		contentPane.add(journal);
			
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
