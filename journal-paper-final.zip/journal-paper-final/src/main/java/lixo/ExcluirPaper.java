package lixo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import errors.PaperNaoEncontradoException;
import models.Paper;
import service.PaperService;
import javax.swing.SwingConstants;

public class ExcluirPaper extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static PaperService  paperAppService;
	static
    {
    	@SuppressWarnings("resource")
		ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");

    	paperAppService = (PaperService)fabrica.getBean ("PaperService");
    }
	
	@SuppressWarnings("unchecked")
	public ExcluirPaper() {
		List<Paper> papers = paperAppService.recuperaPapers();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEscolhaOPaper = new JLabel("Escolha o paper a ser exclu�do:");
		lblEscolhaOPaper.setHorizontalAlignment(SwingConstants.CENTER);
		lblEscolhaOPaper.setFont(new Font("Arial", Font.PLAIN, 16));
		lblEscolhaOPaper.setBounds(0, 68, 434, 37);
	
		contentPane.add(lblEscolhaOPaper);
		
		@SuppressWarnings("rawtypes")
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					paperAppService.exclui(paperAppService.recuperaUmPaper(papers.get(comboBox.getSelectedIndex()).getId()));
				} catch (PaperNaoEncontradoException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Paper excluido com sucesso !");
				dispose();
			}
		});
		comboBox.setBounds(46, 116, 356, 19);
		comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
		comboBox.setModel(new DefaultComboBoxModel<Object>(papers.toArray()));
		contentPane.add(comboBox);
		
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Arial", Font.PLAIN, 12));
		btnCancelar.setBounds(165, 182, 109, 31);
		contentPane.add(btnCancelar);
		
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
	}
}
