package lixo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import errors.ObjetoNaoEncontradoException;
import errors.JournalNaoEncontradoException;
import models.Paper;
import models.Journal;
import service.PaperService;
import service.JournalService;
import util.PapersModel;

public class ExibirPapers extends JFrame implements ActionListener {

	
	private static final long serialVersionUID = 1L;
	private JPanel Panel;
	private JTable table_1;
	private JScrollPane scrollPane;
	private List<Paper> f;
	PapersModel papers;
	Journal aux;
	 private static JournalService  journalAppService;
		@SuppressWarnings("unused")
		private Journal umJournal;
		
		 static {
		    	@SuppressWarnings("resource")
				ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");
		    	journalAppService = (JournalService)fabrica.getBean ("JournalService");
		    }
		 
	@SuppressWarnings("unused")
	private Paper umPaper;
	private static PaperService  paperAppService;
	 static {
	    	@SuppressWarnings("resource")
			ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");
	    	paperAppService = (PaperService)fabrica.getBean ("PaperService");
	    }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ExibirPapers() {
		List<Journal> journals = journalAppService.recuperaListaDeJournalsEPapers();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 630, 500);
		Panel = new JPanel();
		Panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Panel);
		Panel.setLayout(null);
			
		JLabel journal = new JLabel("Selecione o Journal:");
		journal.setFont(new Font("Arial", Font.PLAIN, 14));
		journal.setBounds(10, 29, 159, 21);
		Panel.add(journal);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					 aux = journalAppService.recuperaUmJournal(journals.get(comboBox.getSelectedIndex()).getId());
					 papers = new PapersModel(aux.getId());
					
					
					
					
					table_1 = new JTable();
					table_1.setBounds(20, 60, 600, 300);
					Panel.add(table_1);
					
					table_1.setModel(papers);
					
					table_1.setVisible(true);
					
					scrollPane = new JScrollPane();
					scrollPane.setVisible(true);
					scrollPane.setBounds(24, 61, 517, 233);
					getContentPane().add(scrollPane);
					
					scrollPane.setViewportView(table_1);
					
					scrollPane.setVisible(true);

				} catch (JournalNaoEncontradoException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		comboBox.setBounds(177, 30, 398, 21);
		comboBox.setModel(new DefaultComboBoxModel<Object>(journals.toArray()));
		Panel.add(comboBox);
		
		
		JButton voltar = new JButton("Voltar");
		voltar.setFont(new Font("Arial", Font.PLAIN, 12));
		voltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		voltar.setBounds(269, 385, 127, 36);
		Panel.add(voltar);
		
	}


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
