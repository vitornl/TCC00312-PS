package lixo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import errors.ViolacaoDeConstraintDesconhecidaException;
import models.Journal;
import service.JournalService;

public class RegistraJournal extends JFrame implements ActionListener {

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private String resp;
	private JTextField textoValor;
	private JTextField textoVolume;
	private Journal umJournal;
	
	
    @SuppressWarnings("resource")
	ApplicationContext fabrica = new ClassPathXmlApplicationContext("beans-jpa.xml");	    
	   JournalService journalAppService = (JournalService)fabrica.getBean ("JournalService");
	    	
	    
		
	public RegistraJournal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 628, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JTextField textoNome;
		contentPane.setLayout(null);
		textoNome = new JTextField();
		textoNome.setBounds(159, 43, 356, 26);
		getContentPane().add(textoNome);
		textoNome.setColumns(10);
		
		JLabel textoJournals = new JLabel("Nome do Journal:");
		textoJournals.setFont(new Font("Arial", Font.PLAIN, 14));
		textoJournals.setBounds(44, 42, 89, 26);
		getContentPane().add(textoJournals);
		
		JLabel labelVolume = new JLabel("Volume:");
		labelVolume.setFont(new Font("Arial", Font.PLAIN, 14));
		labelVolume.setBounds(87, 134, 46, 21);
		getContentPane().add(labelVolume);
		
		JLabel labelValor = new JLabel("Valor:");
		labelValor.setFont(new Font("Arial", Font.PLAIN, 14));
		labelValor.setBounds(87, 185, 48, 26);
		contentPane.add(labelValor);
		
		textoValor = new JTextField();
		textoValor.setBounds(159, 189, 113, 21);
		contentPane.add(textoValor);
		textoValor.setColumns(10);
		
		textoVolume = new JTextField();
		textoVolume.setBounds(159, 135, 36, 21);
		contentPane.add(textoVolume);
		textoVolume.setColumns(10);
		
		JButton botao_de_Cadastrar = new JButton("Cadastrar");
		botao_de_Cadastrar.setFont(new Font("Arial", Font.PLAIN, 14));
		botao_de_Cadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean valido = true;
				try{
					Float aux = Float.parseFloat(textoValor.getText());
					umJournal = new Journal();
					umJournal.setNome(textoNome.getText().toUpperCase().trim());
					umJournal.setVolume(Integer.parseInt(textoVolume.getText()));
					umJournal.setValor(aux);
					journalAppService.inclui(umJournal);
				}
				catch(NumberFormatException | ViolacaoDeConstraintDesconhecidaException ex){
					valido = false;
					JOptionPane.showMessageDialog(null, "Informa��es invalidas, reveja os campos !");		
				}
				if(valido){
					JOptionPane.showMessageDialog(null, "Journal cadastrado Com sucesso !");
				    dispose();
				}
			}
		});
		botao_de_Cadastrar.setBounds(131, 276, 126, 41);
		contentPane.add(botao_de_Cadastrar);
		
		JButton botaoVoltar = new JButton("Voltar");
		botaoVoltar.setFont(new Font("Arial", Font.PLAIN, 14));
		botaoVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		botaoVoltar.setBounds(397, 276, 126, 41);
		contentPane.add(botaoVoltar);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
