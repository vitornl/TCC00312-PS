package lixo;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



public class FramePrincipal extends JFrame implements ActionListener {
 private JMenuBar menuBar;
 private JMenu botaoIniciar;
 private static FramePrincipal frame;
 
	private static final long serialVersionUID = 1L;
	private JButton registraJournal;
	private JButton registraPaper;
	private JButton exibirPapers;
	private JButton exibirJournals;
	private JButton excluirJournal;
	private JButton excluirPaper;
	
	public FramePrincipal() {
		setResizable(false);
		this.setBounds(100, 100, 628, 382);
		getContentPane().setLayout(null);
		
		
		registraJournal = new JButton("Cadastrar Journal");
		registraJournal.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		registraJournal.setBounds(206, 100, 200, 35);
		getContentPane().add(registraJournal);
		registraJournal.setVisible(false);
		registraJournal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegistraJournal journal = new RegistraJournal();
				journal.setVisible(true);
				
			}
		});
		
		
		registraPaper = new JButton("Cadastrar Paper");
		registraPaper.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		registraPaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RegistraPaper novoPaper = new RegistraPaper();
				novoPaper.setVisible(true);
			}
		});
		registraPaper.setBounds(206, 146, 200, 35);
		getContentPane().add(registraPaper);
		registraPaper.setVisible(false);
		
		exibirPapers = new JButton("Exibir Papers");
		exibirPapers.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		exibirPapers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ExibirPapers dep = new ExibirPapers();
				dep.setVisible(true);
			}
		});
		exibirPapers.setBounds(206, 146, 200, 35);
		getContentPane().add(exibirPapers);
		exibirPapers.setVisible(false);
		
		exibirJournals = new JButton("Exibir Journals");
		exibirJournals.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		exibirJournals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ExibirJournals novoResp = new ExibirJournals();
				novoResp.setVisible(true);
			}
		});
		exibirJournals.setBounds(206, 100, 200, 35);
		getContentPane().add(exibirJournals);
		
		excluirPaper = new JButton("Excluir Paper");
		excluirPaper.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		excluirPaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ExcluirPaper exdep= new ExcluirPaper();
				exdep.setVisible(true);
			}
		});
		excluirPaper.setBounds(206, 100, 200, 35);
		getContentPane().add(excluirPaper);
		excluirPaper.setVisible(false);
		
		excluirJournal = new JButton("Excluir Journal");
		excluirJournal.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 12));
		excluirJournal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExcluirJournal exF = new ExcluirJournal();
				exF.setVisible(true);
			}
		});
		excluirJournal.setBounds(206, 146, 200, 35);
		excluirJournal.setVisible(false);
		getContentPane().add(excluirJournal);
		
		JLabel menuExclusao = new JLabel("Menu de exclus\u00E3o");
		menuExclusao.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 20));
		menuExclusao.setHorizontalAlignment(SwingConstants.CENTER);
		menuExclusao.setBounds(206, 40, 200, 35);
		getContentPane().add(menuExclusao);
		menuExclusao.setVisible(false);
		
		JLabel menuExibicao = new JLabel("Menu de exibi\u00E7\u00E3o");
		menuExibicao.setHorizontalAlignment(SwingConstants.CENTER);
		menuExibicao.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 20));
		menuExibicao.setBounds(206, 40, 200, 35);
		getContentPane().add(menuExibicao);
		menuExibicao.setVisible(false);
		
		JLabel menuCadastro = new JLabel("Menu de cadastro");
		menuCadastro.setHorizontalAlignment(SwingConstants.CENTER);
		menuCadastro.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 20));
		menuCadastro.setBounds(206, 40, 200, 35);
		getContentPane().add(menuCadastro);
		exibirJournals.setVisible(false);
		menuCadastro.setVisible(false);
		
			
		 menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
	    botaoIniciar = new JMenu("Iniciar");
		menuBar.add(botaoIniciar);
	
		
		JMenuItem botaoCadastrar = new JMenuItem("Cadastrar");
		botaoCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj =  e.getSource();
				if(obj==botaoCadastrar){
					
					registraJournal.setVisible(true);
					registraPaper.setVisible(true);
					exibirPapers.setVisible(false);
		            exibirJournals.setVisible(false);
		            excluirPaper.setVisible(false);
		            excluirJournal.setVisible(false);
		            menuCadastro.setVisible(true);
		            menuExclusao.setVisible(false);
		            menuExibicao.setVisible(false);
				}
								
			}
		});
		botaoIniciar.add(botaoCadastrar);
		
		JMenuItem botaoBuscar = new JMenuItem("Buscar / Atualizar");
		botaoBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object obj =  e.getSource();
				if(obj==botaoBuscar){
					registraJournal.setVisible(false);
					registraPaper.setVisible(false);
					exibirPapers.setVisible(true);
					exibirJournals.setVisible(true);
					excluirPaper.setVisible(false);
					excluirJournal.setVisible(false);
					menuCadastro.setVisible(false);
					menuExclusao.setVisible(false);
					menuExibicao.setVisible(true);
				}
				
			}
		});
		botaoIniciar.add(botaoBuscar);
		
		JMenuItem botaoExcluir = new JMenuItem("Excluir");
		botaoExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registraJournal.setVisible(false);
				registraPaper.setVisible(false);
				exibirPapers.setVisible(false);
			    exibirJournals.setVisible(false);
			    excluirPaper.setVisible(true);
			    excluirJournal.setVisible(true);
			    menuCadastro.setVisible(false);
			    menuExclusao.setVisible(true);
			    menuExibicao.setVisible(false);				
			}
		});
		botaoIniciar.add(botaoExcluir);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new FramePrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//Object obj = e.getSource();
		
	}
}
