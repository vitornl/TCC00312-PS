package views;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class FramePrincipal2 extends JFrame
{
	private static final long serialVersionUID = 1L;

	private JMenuItem menuItemJournal;
	private JMenuItem menuItemPaper;
	private JMenuItem menuItemSair;
	private JDesktopPane desktopPane;
	private JFrame framePrincipal;
	
	public FramePrincipal2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 614, 345);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnMenu = new JMenu("Menu");
		menuBar.add(mnMenu);
		
		framePrincipal = this;
		
		menuItemJournal = new JMenuItem("Journal");
		menuItemJournal.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J, ActionEvent.ALT_MASK)); // Diz a combina��o necessaria para chamar os action listeners
		menuItemJournal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DialogJournal dialogJournal = new DialogJournal(framePrincipal);
				dialogJournal.novo();
				dialogJournal.setVisible(true);
			}
		});
		mnMenu.add(menuItemJournal);
		
		menuItemPaper = new JMenuItem("Paper");
		menuItemPaper.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.ALT_MASK)); // Diz a combina��o necessaria para chamar os action listeners
		menuItemPaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DialogPaper dialogPaper = new DialogPaper(framePrincipal);
				dialogPaper.novo();
				dialogPaper.setVisible(true);
			}
		});
		mnMenu.add(menuItemPaper);
		
		menuItemSair = new JMenuItem("Sair");
		menuItemSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK)); // Diz a combina��o necessaria para chamar os action listeners
		menuItemSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		mnMenu.add(menuItemSair);
			
		getContentPane().setLayout(null);
		
		desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.LIGHT_GRAY);
		desktopPane.setBounds(0, 0, 598, 286);
		getContentPane().add(desktopPane);
		
		try
		{
			UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
		}
		catch(ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e1) {
			e1.printStackTrace();
		}
}
}
